package questao03;

public class Cachorro implements Locomocao{

	@Override
	public void quantidadeDeMembros() {
System.out.println("O cachorro tem 4 membros");		
	}

}
