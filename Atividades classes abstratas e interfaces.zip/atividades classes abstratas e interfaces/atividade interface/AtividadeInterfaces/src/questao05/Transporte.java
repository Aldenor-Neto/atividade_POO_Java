package questao05;

public interface Transporte {

	String nome;
	int numeroPassageiros;
	int velocidadeAtual;
	
	public Boolean estaParado();
	
}
