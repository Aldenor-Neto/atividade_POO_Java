package questao05;

public interface TransporteTerrestre extends Transporte{

	private String tipo;
	
	public void estacionar();
	
}
